#include "DHT.h"


#define LED_PIN 5
#define DHTPIN 4
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);

void setup()
{
  Serial.begin(115200);
  dht.begin();
  pinMode(LED_PIN, OUTPUT);
 
}

void loop()
{
  float temperature;
  float humidity;

  temperature = dht.readTemperature();
  humidity = dht.readHumidity();

 if (temperature > 30)
{
  digitalWrite(LED_PIN, HIGH);
 
  Serial.println("Status: HIGH TEMPERATURE!");
}
else
{
  digitalWrite(LED_PIN, LOW);
 
  Serial.println("Status: NORMAL");
}

  Serial.print("Temperature: ");
  Serial.print(temperature);
  Serial.println(" C");

  Serial.print("Humidity: ");
  Serial.print(humidity);
  Serial.println(" %");

  delay(2000);
}